# si20406.uts
Gema Nurrohman ( 1941448 )
